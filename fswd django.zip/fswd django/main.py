import mysql.connector

mydb = mysql.connector.connect(host='localhost', user='root', passwd='123456789', database='pschool', autocommit=True)
# sub1 = 80
# sub2 = 34
# sub3 = 56
# total_marks= sub1+sub2+sub3
cursor = mydb.cursor()

# cursor.execute("insert into class1(name,age,reg,marks,city)values('smith',20,3,76,'mysore')")
# cursor.execute("insert into class1(name,age,reg,marks,city)values('rob',20,3,%s,'mysore')",(total_marks,))

cursor.execute("select * from class1 where name='tushar'")
x = cursor.fetchone()
print(x)