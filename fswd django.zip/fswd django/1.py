a=10
b=20
res = a+b
print(res)
a = '10'
b = '20'
res = a+b
print(res)
a = int(a)
b = int(b)
res = a+b
print(res)
