from audioop import add
from email import message
from turtle import pos
from click import pass_obj
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.contrib.auth.models import User, auth
from django.contrib import messages
from accounts.models import pltinsert

def donateplt(request):
    if request.method=='POST':
        nurname = request.POST['nurname']
        email = request.POST['email']
        phone = request.POST['phone']
        address = request.POST['address']
        plantsdesc = request.POST['plantsdesc']

        newrec = pltinsert(nurname=nurname, email = email, phone=phone, address=address, plantsdesc=plantsdesc)
        newrec.save()

        
        return render(request,'formdonor.html')
    else:
        return render(request,'formdonor.html')

def buyplt(request):
    if request.method=='POST':
        nurname = request.POST['nurname']
        email = request.POST['email']
        phone = request.POST['phone']
        address = request.POST['address']
        plantsdesc = request.POST['plantsdesc']

        newrec = pltinsert(nurname=nurname, email = email, phone=phone, address=address, plantsdesc=plantsdesc)
        newrec.save()

        
        return render(request,'formbuyer.html')
    else:
        return render(request,'formbuyer.html')



# Create your views here.
def homepage(request):
    return render(request,'homepage.html')

def contact(request):
    return render(request,'contact.html')

def about(request):
    return render(request,'about.html')

def thankyou(request):
    return render(request,'Thankyou.html')

def thankyoudonor(request):
    return render(request,'thankyoudonor.html')

def thankyoubuyer(request):
    return render(request,'thankyoubuyer.html')

def employee(request):
    return render(request,'employee.html')

def accounts(request):
    return HttpResponse("This is accounts page")

def buySignin(request):
    # return render(request,'login.html')
    if request.method =='POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password = password)

        if user is not None:
            auth.login(request,user)
            print("Logged in")
            return redirect('/')
    else:
        return render(request,'buySignin.html')
def donateSignin(request):
    # return render(request,'login.html')
    if request.method =='POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password = password)

        if user is not None:
            auth.login(request,user)
            print("Logged in")
            return redirect('/')
    else:
        return render(request,'donateSignin.html')
def buySignup(request):
    # return render(request,'signup.html')
    if request.method == 'POST':
        firstName = request.POST['firstName']
        lastName = request.POST['lastName']
        username = request.POST['userName']
        email = request.POST['email']
        password = request.POST['password']

        user = User.objects.create_user(username = username, email = email, password = password, first_name = firstName, last_name = lastName)
        print("User created")
        return redirect('/thankyou')
    else:
        return render(request,'buySignup.html')

def donateSignup(request):
    # return render(request,'signup.html')
    if request.method == 'POST':
        firstName = request.POST['firstName']
        lastName = request.POST['lastName']
        username = request.POST['userName']
        email = request.POST['email']
        password = request.POST['password']

        user = User.objects.create_user(username = username, email = email, password = password, first_name = firstName, last_name = lastName)
        print("User created")
        return redirect('/thankyou')
    else:
        return render(request,'donateSignup.html')


