from django.contrib import admin
from django.urls import path

from . import views
urlpatterns = [
    path("buySignup", views.buySignup),
    path("", views.homepage),
    path("contact", views.contact),
    path("employee", views.employee),
    path("about", views.about),
    path("donateSignup", views.donateSignup),
    path("buySignin", views.buySignin),
    path("donateSignin", views.donateSignin),
    path("thankyou", views.thankyou),
    path("thankyoudonor", views.thankyoudonor),
    path("thankyoubuyer", views.thankyoubuyer),
    path("formdonor", views.donateplt),
    path("formbuyer", views.buyplt),

    
    
]