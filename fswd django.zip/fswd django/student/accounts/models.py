from django.db import models

# Create your models here.
class pltinsert(models.Model):
    nurname = models.CharField(max_length=100)
    email= models.CharField(max_length=100)
    phone= models.IntegerField(max_length=20)
    address= models.CharField(max_length=500)
    plantsdesc= models.TextField

    def __str__(self):
        return self.title
    
